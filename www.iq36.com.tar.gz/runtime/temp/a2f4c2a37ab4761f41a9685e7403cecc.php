<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:75:"/www/wwwroot/www.iq36.com/public/../application/index/view/index/index.html";i:1515585078;s:77:"/www/wwwroot/www.iq36.com/public/../application/index/view/public/header.html";i:1515209566;s:77:"/www/wwwroot/www.iq36.com/public/../application/index/view/public/footer.html";i:1515137238;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>哈尔滨PHP</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="keywords" content="PHP,Thinkphp,框架">
  <meta name="description" content="PHP论坛哈尔滨论坛，讨论PHP框架论坛">
  <link rel="stylesheet" href="__STATIC__/layui/css/layui.css">
  <link rel="stylesheet" href="__STATIC__/css/global.css">
  <style>
    .pagination{text-align:center;margin-top:20px;margin-bottom: 20px;}
    .pagination li{margin:0px 1px; border:1px solid #009688;padding: 3px 8px;display: inline-block;}
    .pagination .active{background-color: #009688;color: #fff;}
    .pagination .disabled{color:#aaa;}
  </style>
</head>
<body>
<div class="fly-header layui-bg-black">
  <div class="layui-container">
    <a class="fly-logo" href="/">
      <img src="__STATIC__/images/logo.png" height="50" alt="layui">
    </a>
    <ul class="layui-nav fly-nav layui-hide-xs">
      <li class="layui-nav-item layui-this">
        <a href="/"><i class="iconfont icon-jiaoliu"></i>交流</a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('index/index/addnews'); ?>"><i class="iconfont icon-fabu"></i>发表</a>
      </li>
      <li class="layui-nav-item">
        <a href="/" target="_blank"><i class="iconfont icon-shijian"></i><?php echo date('Y-m-d H:i:s')?></a>
      </li>
    </ul>
    
    <ul class="layui-nav fly-nav-user">
      
      <!-- 未登入的状态 -->
      <?php if((session('id','','index') < 1)): ?>
      <li class="layui-nav-item">
        <a class="iconfont icon-touxiang layui-hide-xs" href="../user/login.html"></a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('index/User/login'); ?>">登入</a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('Index/User/reg'); ?>">注册</a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过QQ登入', {icon:16, shade: 0.1, time:0})" title="QQ登入" class="iconfont icon-qq"></a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过微博登入', {icon:16, shade: 0.1, time:0})" title="微博登入" class="iconfont icon-weibo"></a>
      </li>
      <?php else: ?>
      <!-- 登入后的状态 -->

      <li class="layui-nav-item">
        <a class="fly-nav-avatar" href="javascript:;">
          <cite class="layui-hide-xs"><?php echo session('username','','index')?></cite>
          <!--<i class="iconfont icon-renzheng layui-hide-xs" title="认证信息：layui 作者"></i>-->
          <i class="layui-badge fly-badge-vip layui-hide-xs">会员</i>
          <img src="/<?php echo session('tx','','index')?>">
        </a>
        <dl class="layui-nav-child">
          <dd><a href="<?php echo url('index/User/set'); ?>"><i class="layui-icon">&#xe620;</i>基本设置</a></dd>
          <dd><a href="<?php echo url('index/User/index'); ?>"><i class="iconfont icon-tongzhi" style="top: 4px;"></i>我的发帖</a></dd>
          <dd><a href="<?php echo url('index/User/home'); ?>"><i class="layui-icon" style="margin-left: 2px; font-size: 22px;">&#xe68e;</i>我的主页</a></dd>
          <hr style="margin: 5px 0;">
          <dd><a href="<?php echo url('index/User/logout'); ?>" style="text-align: center;">退出</a></dd>
        </dl>
      </li>

      <?php endif; ?>
    </ul>
  </div>
</div>


<div class="fly-panel fly-column">
  <div class="layui-container">
    <ul class="layui-clear">
      <li class="layui-hide-xs layui-this"><a href="/">首页</a></li> 
      <li><a href="<?php echo url('index/index/addnews'); ?>">发帖</a></li>
      <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
      <li><a href="<?php echo url('Index/index/index',array('list_id'=>$vo['id'])); ?>">
        <?php echo $vo['name']; if(($vo['name'] == '分享')): ?>
        <span class="layui-badge-dot"></span>
        <?php endif; ?>
          </a>
      </li>
      <?php endforeach; endif; else: echo "" ;endif; ?>
      <li class="layui-hide-xs layui-hide-sm layui-show-md-inline-block"><span class="fly-mid"></span></li> 
      
      <!-- 用户登入后显示 -->
      <!--<li class="layui-hide-xs layui-hide-sm layui-show-md-inline-block"><a href="user/index.html">我发表的贴</a></li> -->
      <!--<li class="layui-hide-xs layui-hide-sm layui-show-md-inline-block"><a href="user/index.html#collection">我收藏的贴</a></li> -->
    </ul> 
    
    <div class="fly-column-right layui-hide-xs"> 
      <span class="fly-search"><i class="layui-icon"></i></span> 
      <a href="<?php echo url('index/index/addnews'); ?>" class="layui-btn">发表新帖</a>
    </div> 
    <div class="layui-hide-sm layui-show-xs-block" style="margin-top: -10px; padding-bottom: 10px; text-align: center;"> 
      <a href="<?php echo url('index/index/addnews'); ?>" class="layui-btn">发表新帖</a>
    </div> 
  </div>
</div>

<div class="layui-container">
  <div class="layui-row layui-col-space15">
    <div class="layui-col-md8">
      <div class="fly-panel">
        <div class="fly-panel-title fly-filter">
          <a>置顶</a>
          <a href="#signin" class="layui-hide-sm layui-show-xs-block fly-right" id="LAY_goSignin" style="color: #FF5722;">去签到</a>
        </div>
        <ul class="fly-list">
          <?php if(is_array($top) || $top instanceof \think\Collection || $top instanceof \think\Paginator): $i = 0; $__LIST__ = $top;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <li>
            <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>" class="fly-avatar">
              <img src="/<?php echo $vo['tx']; ?>" alt="贤心">
            </a>
            <h2>
              <a class="layui-badge"><?php echo $vo['cname']; ?></a>
              <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>"><?php echo $vo['title']; ?></a>
            </h2>
            <div class="fly-list-info">
              <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>" link>
                <cite><?php echo $vo['username']; ?></cite>
                <!--<i class="iconfont icon-renzheng" title="认证信息：XXX"></i>-->
                <!--<i class="layui-badge fly-badge-vip">VIP3</i>-->
              </a>
              <span><?php echo date("y-m-m H:i:s",$vo['create_time']); ?></span>

              <span class="fly-list-kiss layui-hide-xs" title="悬赏钻石"><i class="layui-icon">&#xe735;</i> <?php echo $vo['jifen']; ?></span>
              <?php if(($vo['end'] == 1)): ?>
              <span class="layui-badge fly-badge-accept layui-hide-xs">已结</span>
              <?php endif; ?>
              <span class="fly-list-nums">
                <i class="iconfont icon-pinglun1" title="回答"></i><?php echo $vo['host']; ?>
              </span>
            </div>
            <div class="fly-list-badge">
              <?php if(($vo['jing'] == 1)): ?>
              <span class="layui-badge layui-bg-red">精帖</span>
              <?php endif; ?>
            </div>
          </li>
          <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
      </div>

      <div class="fly-panel" style="margin-bottom: 0;">
        
        <div class="fly-panel-title fly-filter">
          <a href="/" class="layui-this">综合</a>
          <span class="fly-mid"></span>

          <a href="<?php echo url('index/Index/index',array('end'=>'w')); ?>">未结</a>

          <span class="fly-mid"></span>
          <a href="<?php echo url('index/Index/index',array('end'=>1)); ?>">已结</a>
          <span class="fly-mid"></span>
          <a href="<?php echo url('index/Index/index',array('jing'=>1)); ?>">精华</a>
          <span class="fly-filter-right layui-hide-xs">
            <a href="/" class="layui-this">按最新</a>
            <span class="fly-mid"></span>
            <a href="<?php echo url('index/Index/index',array('desc'=>'desc')); ?>">按热议</a>
          </span>
        </div>

        <ul class="fly-list">
          <?php if(is_array($news) || $news instanceof \think\Collection || $news instanceof \think\Paginator): $i = 0; $__LIST__ = $news;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <li>
            <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>" class="fly-avatar">
              <img src="/<?php echo $vo['tx']; ?>" alt="贤心">
            </a>
            <h2>
              <a class="layui-badge"><?php echo $vo['cname']; ?></a>
              <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>"><?php echo $vo['title']; ?></a>
            </h2>
            <div class="fly-list-info">
              <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>" link>
                <cite><?php echo $vo['username']; ?></cite>
                <!--<i class="iconfont icon-renzheng" title="认证信息：XXX"></i>-->
                <!--<i class="layui-badge fly-badge-vip">VIP3</i>-->
              </a>
              <span><?php echo date("y-m-m H:i:s",$vo['create_time']); ?></span>
              
              <span class="fly-list-kiss layui-hide-xs" title="悬赏钻石"><i class="layui-icon">&#xe735;</i> <?php echo $vo['jifen']; ?></span>
              <?php if(($vo['end'] == 1)): ?>
              <span class="layui-badge fly-badge-accept layui-hide-xs">已结</span>
              <?php endif; ?>
              <span class="fly-list-nums"> 
                <i class="iconfont icon-pinglun1" title="人气"></i> <?php echo $vo['host']; ?>
              </span>
            </div>
            <div class="fly-list-badge">
              <?php if(($vo['jing'] == 1)): ?>
              <span class="layui-badge layui-bg-red">精帖</span>
              <?php endif; ?>
            </div>
          </li>
          <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
        <div style="text-align: center">
          <?php echo $news->render(); ?>
        </div>
        <!--<div style="text-align: center">-->
          <!--<div class="laypage-main">-->
            <!--<a href="jie/index.html" class="laypage-next">更多求解</a>-->
          <!--</div>-->
        <!--</div>-->

      </div>
    </div>
    <div class="layui-col-md4">

      <div class="fly-panel">
        <h3 class="fly-panel-title">温馨通道</h3>
        <ul class="fly-panel-main fly-list-static">
          <?php if(is_array($wx) || $wx instanceof \think\Collection || $wx instanceof \think\Paginator): $i = 0; $__LIST__ = $wx;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <li>
            <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>" target="_blank"><?php echo $vo['title']; ?></a>
          </li>
          <?php endforeach; endif; else: echo "" ;endif; ?>
        </ul>
      </div>


      <div class="fly-panel fly-signin">
        <div class="fly-panel-title">
          签到
          <i class="fly-mid"></i>
          <a href="javascript:;" class="fly-link" id="LAY_signinHelp">钻石说明</a>
          <i class="fly-mid"></i>
          <!--<a href="javascript:;" class="fly-link" id="LAY_signinTop">活跃榜<span class="layui-badge-dot"></span></a>-->
          <!--<span class="fly-signin-days">已连续签到<cite>16</cite>天</span>-->
        </div>
        <div class="fly-panel-main fly-signin-main">
          <button class="layui-btn layui-btn-danger" id="LAY_signin">今日签到</button>
          <span>可获得<cite>10</cite>钻石</span>
          
          <!-- 已签到状态 -->
          <!--
          <button class="layui-btn layui-btn-disabled">今日已签到</button>
          <span>获得了<cite>20</cite>飞吻</span>
          -->
        </div>
      </div>

      <div class="fly-panel fly-rank fly-rank-reply" id="LAY_replyRank">
        <h3 class="fly-panel-title">回贴周榜</h3>
        <dl>
          <!--<i class="layui-icon fly-loading">&#xe63d;</i>-->
          <?php if(is_array($ht) || $ht instanceof \think\Collection || $ht instanceof \think\Paginator): $i = 0; $__LIST__ = $ht;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <dd>
            <a href="">
              <img src="/<?php echo $vo['tx']; ?>"><cite><?php echo $vo['username']; ?></cite><i><?php echo $vo['num']; ?></i>
            </a>
          </dd>
          <?php endforeach; endif; else: echo "" ;endif; ?>




        </dl>
      </div>

      <dl class="fly-panel fly-list-one">
        <dt class="fly-panel-title">本周热议</dt>
        <?php if(is_array($re) || $re instanceof \think\Collection || $re instanceof \think\Paginator): $i = 0; $__LIST__ = $re;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <dd>
          <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>"><?php echo $vo['title']; ?></a>
          <span><i class="iconfont icon-pinglun1"></i><?php echo $vo['num']; ?></span>
        </dd>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        <!-- 无数据时 -->
        <!--
        <div class="fly-none">没有相关数据</div>
        -->
      </dl>

      <!--<div class="fly-panel">-->
        <!--<div class="fly-panel-title">-->
          <!--这里可作为广告区域-->
        <!--</div>-->
        <!--<div class="fly-panel-main">-->
          <!--<a href="http://layim.layui.com/?from=fly" target="_blank" class="fly-zanzhu" time-limit="2017.09.25-2099.01.01" style="background-color: #5FB878;">LayIM 3.0 - layui 旗舰之作</a>-->
        <!--</div>-->
      <!--</div>-->
      <!---->
      <div class="fly-panel fly-link">
        <h3 class="fly-panel-title">友情链接</h3>
        <dl class="fly-panel-main">
          <dd><a href="http://www.okadwin.com/" target="_blank">adwin</a><dd>
	  <dd><a href="http://www.emmet.tech/"  target="_blank">emmet</a></dd>
          <!--<dd><a href="http://layim.layui.com/" target="_blank">WebIM</a><dd>-->
          <!--<dd><a href="http://layer.layui.com/" target="_blank">layer</a><dd>-->
          <!--<dd><a href="http://www.layui.com/laydate/" target="_blank">layDate</a><dd>-->
          <!--<dd><a href="mailto:xianxin@layui-inc.com?subject=%E7%94%B3%E8%AF%B7Fly%E7%A4%BE%E5%8C%BA%E5%8F%8B%E9%93%BE" class="fly-link">申请友链</a><dd>-->
        </dl>
      </div>

    </div>
  </div>
</div>

<div class="fly-footer">
  <!--<p><a href="http://fly.layui.com/" target="_blank">Fly社区</a> 2017 &copy; <a href="http://www.layui.com/" target="_blank">layui.com 出品</a></p>-->
  <!--<p>-->
    <!--<a href="http://fly.layui.com/jie/3147/" target="_blank">付费计划</a>-->
    <!--<a href="http://www.layui.com/template/fly/" target="_blank">获取Fly社区模版</a>-->
    <!--<a href="http://fly.layui.com/jie/2461/" target="_blank">微信公众号</a>-->
  <!--</p>-->
</div>

<script src="__STATIC__/layui/layui.js"></script>
<script>
layui.cache.page = '';
layui.cache.user = {
  username: '游客'
  ,uid: -1
  ,avatar: '__STATIC__/images/avatar/00.jpg'
  ,experience: 83
  ,sex: '男'
};
layui.config({
  version: "3.0.0"
  ,base: '__STATIC__/mods/'  //这里实际使用时，建议改成绝对路径
}).extend({
  fly: 'index'
}).use(['fly', 'face'], function(){
  var $ = layui.$
          ,fly = layui.fly;

  $('.jieda-body').each(function(){
    var othis = $(this), html = othis.html();
    othis.html(fly.content(html));
  });

});
</script>

<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_30088308'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/c.php%3Fid%3D30088308' type='text/javascript'%3E%3C/script%3E"));</script>
</body>
</html>
