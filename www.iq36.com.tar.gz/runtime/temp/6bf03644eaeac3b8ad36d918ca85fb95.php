<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:61:"E:\www\WWW\wd\public/../application/index\view\user\home.html";i:1515136015;s:65:"E:\www\WWW\wd\public/../application/index\view\public\header.html";i:1515137194;s:65:"E:\www\WWW\wd\public/../application/index\view\public\footer.html";i:1514967682;}*/ ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>用户主页</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="keywords" content="fly,layui,前端社区">
  <meta name="description" content="Fly社区是模块化前端UI框架Layui的官网社区，致力于为web开发提供强劲动力">
  <link rel="stylesheet" href="__STATIC__/layui/css/layui.css">
  <link rel="stylesheet" href="__STATIC__/css/global.css">
</head>
<body style="margin-top: 65px;">
<div class="fly-header layui-bg-black">
  <div class="layui-container">
    <a class="fly-logo" href="/">
      <img src="__STATIC__/images/logo.png" alt="layui">
    </a>
    <ul class="layui-nav fly-nav layui-hide-xs">
      <li class="layui-nav-item layui-this">
        <a href="/"><i class="iconfont icon-jiaoliu"></i>交流</a>
      </li>
      <li class="layui-nav-item">
        <a href="case/case.html"><i class="iconfont icon-iconmingxinganli"></i>案例</a>
      </li>
      <li class="layui-nav-item">
        <a href="http://www.layui.com/" target="_blank"><i class="iconfont icon-ui"></i>框架</a>
      </li>
    </ul>
    
    <ul class="layui-nav fly-nav-user">
      
      <!-- 未登入的状态 -->
      <?php if((session('id','','index') < 1)): ?>
      <li class="layui-nav-item">
        <a class="iconfont icon-touxiang layui-hide-xs" href="../user/login.html"></a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('index/User/login'); ?>">登入</a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('Index/User/reg'); ?>">注册</a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过QQ登入', {icon:16, shade: 0.1, time:0})" title="QQ登入" class="iconfont icon-qq"></a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过微博登入', {icon:16, shade: 0.1, time:0})" title="微博登入" class="iconfont icon-weibo"></a>
      </li>
      <?php else: ?>
      <!-- 登入后的状态 -->

      <li class="layui-nav-item">
        <a class="fly-nav-avatar" href="javascript:;">
          <cite class="layui-hide-xs"><?php echo session('username','','index')?></cite>
          <!--<i class="iconfont icon-renzheng layui-hide-xs" title="认证信息：layui 作者"></i>-->
          <i class="layui-badge fly-badge-vip layui-hide-xs">会员</i>
          <img src="<?php echo session('tx','','index')?>">
        </a>
        <dl class="layui-nav-child">
          <dd><a href="<?php echo url('index/User/set'); ?>"><i class="layui-icon">&#xe620;</i>基本设置</a></dd>
          <dd><a href="<?php echo url('index/User/index'); ?>"><i class="iconfont icon-tongzhi" style="top: 4px;"></i>我的发帖</a></dd>
          <dd><a href="<?php echo url('index/User/home'); ?>"><i class="layui-icon" style="margin-left: 2px; font-size: 22px;">&#xe68e;</i>我的主页</a></dd>
          <hr style="margin: 5px 0;">
          <dd><a href="<?php echo url('index/User/logout'); ?>" style="text-align: center;">退出</a></dd>
        </dl>
      </li>

      <?php endif; ?>
    </ul>
  </div>
</div>
<div class="fly-home fly-panel" style="background-image: url();">
  <img src="<?php echo $info['tx']; ?>" alt="<?php echo $info['username']; ?>">
  <i class="iconfont icon-renzheng" title="Fly社区认证"></i>
  <h1>
    <?php echo $info['username']; ?>
    <i class="iconfont icon-nan"></i>
    <!-- <i class="iconfont icon-nv"></i>  -->
    <i class="layui-badge fly-badge-vip">会员</i>
    <!--
    <span style="color:#c00;">（管理员）</span>
    <span style="color:#5FB878;">（社区之光）</span>
    <span>（该号已被封）</span>
    -->
  </h1>

  <!--<p style="padding: 10px 0; color: #5FB878;">认证信息：layui 作者</p>-->

  <p class="fly-home-info">
    <i class="iconfont icon-kiss" title="飞吻"></i><span style="color: #FF7200;"><?php echo $info['jifen']; ?></span>
    <i class="iconfont icon-shijian"></i><span><?php echo date("Y-m-d",$info['create_time']); ?> 加入</span>
    <!--<i class="iconfont icon-chengshi"></i><span>来自杭州</span>-->
  </p>
  <p class="fly-home-sign"><?php echo $info['content']; ?></p>
  <!--<div class="fly-sns" data-user="">-->
    <!--<a href="javascript:;" class="layui-btn layui-btn-primary fly-imActive" data-type="addFriend">加为好友</a>-->
    <!--<a href="javascript:;" class="layui-btn layui-btn-normal fly-imActive" data-type="chat">发起会话</a>-->
  <!--</div>-->
</div>
<div class="layui-container">
  <div class="layui-row layui-col-space15">
    <div class="layui-col-md6 fly-home-jie">
      <div class="fly-panel">
        <h3 class="fly-panel-title"><?php echo $info['username']; ?> 最近的帖子</h3>
        <ul class="jie-row">
          <?php if(is_array($news) || $news instanceof \think\Collection || $news instanceof \think\Paginator): $i = 0; $__LIST__ = $news;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <li>
            <?php if(($vo['jing'] == 1)): ?>
            <span class="fly-jing">精</span>
            <?php endif; ?>
            <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>" class="jie-title"><?php echo $vo['title']; ?></a>
            <i><?php echo date("Y-m-d H:i:s",$vo['create_time']); ?></i>
            <em class="layui-hide-xs"><?php echo $vo['host']; ?>阅</em>
          </li>
          <?php endforeach; endif; else: echo "" ;endif; ?>
          <!-- <div class="fly-none" style="min-height: 50px; padding:30px 0; height:auto;"><i style="font-size:14px;">没有发表任何求解</i></div> -->
        </ul>
      </div>
    </div>
    
    <div class="layui-col-md6 fly-home-da">
      <div class="fly-panel">
        <h3 class="fly-panel-title"><?php echo $info['username']; ?> 最近的回答</h3>
        <ul class="home-jieda">
          <?php if(is_array($hd) || $hd instanceof \think\Collection || $hd instanceof \think\Paginator): $i = 0; $__LIST__ = $hd;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <li>
          <p>
          <span><?php echo date("y-m-d H:i:s",$vo['create_time']); ?></span>
          在<a href="<?php echo url('index/index/detail',array('id'=>$vo['bid'])); ?>" target="_blank"><?php echo $vo['title']; ?></a>中回答：
          </p>
          <div class="jieda-body home-dacontent">
            <?php echo $vo['content']; ?>
          </div>
        </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>

        
          <!-- <div class="fly-none" style="min-height: 50px; padding:30px 0; height:auto;"><span>没有回答任何问题</span></div> -->
        </ul>
      </div>
    </div>
  </div>
</div>

<div class="fly-footer">
  <p><a href="http://fly.layui.com/" target="_blank">Fly社区</a> 2017 &copy; <a href="http://www.layui.com/" target="_blank">layui.com 出品</a></p>
  <p>
    <a href="http://fly.layui.com/jie/3147/" target="_blank">付费计划</a>
    <a href="http://www.layui.com/template/fly/" target="_blank">获取Fly社区模版</a>
    <a href="http://fly.layui.com/jie/2461/" target="_blank">微信公众号</a>
  </p>
</div>

<script src="__STATIC__/layui/layui.js"></script>
<script>
layui.cache.page = '';
layui.cache.user = {
  username: '游客'
  ,uid: -1
  ,avatar: '__STATIC__/images/avatar/00.jpg'
  ,experience: 83
  ,sex: '男'
};
layui.config({
  version: "3.0.0"
  ,base: '__STATIC__/mods/'  //这里实际使用时，建议改成绝对路径
}).extend({
  fly: 'index'
}).use(['fly', 'face'], function(){
  var $ = layui.$
          ,fly = layui.fly;

  $('.jieda-body').each(function(){
    var othis = $(this), html = othis.html();
    othis.html(fly.content(html));
  });

});
</script>

<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_30088308'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/c.php%3Fid%3D30088308' type='text/javascript'%3E%3C/script%3E"));</script>

</body>
</html>