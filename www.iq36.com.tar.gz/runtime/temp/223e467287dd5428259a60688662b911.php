<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:62:"E:\www\WWW\wd\public/../application/index\view\user\tlist.html";i:1514880960;s:65:"E:\www\WWW\wd\public/../application/index\view\public\header.html";i:1514868949;s:65:"E:\www\WWW\wd\public/../application/index\view\public\footer.html";i:1514967682;}*/ ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>帐号设置</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="keywords" content="fly,layui,前端社区">
  <meta name="description" content="Fly社区是模块化前端UI框架Layui的官网社区，致力于为web开发提供强劲动力">
  <link rel="stylesheet" href="__STATIC__/layui/css/layui.css">
  <link rel="stylesheet" href="__STATIC__/css/global.css">
  <style>
    .pagination{text-align:center;margin-top:20px;margin-bottom: 20px;}
    .pagination li{margin:0px 1px; border:1px solid #009688;padding: 3px 8px;display: inline-block;}
    .pagination .active{background-color: #009688;color: #fff;}
    .pagination .disabled{color:#aaa;}
  </style>
</head>
<body>
<div class="fly-header layui-bg-black">
  <div class="layui-container">
    <a class="fly-logo" href="/">
      <img src="__STATIC__/images/logo.png" alt="layui">
    </a>
    <ul class="layui-nav fly-nav layui-hide-xs">
      <li class="layui-nav-item layui-this">
        <a href="/"><i class="iconfont icon-jiaoliu"></i>交流</a>
      </li>
      <li class="layui-nav-item">
        <a href="case/case.html"><i class="iconfont icon-iconmingxinganli"></i>案例</a>
      </li>
      <li class="layui-nav-item">
        <a href="http://www.layui.com/" target="_blank"><i class="iconfont icon-ui"></i>框架</a>
      </li>
    </ul>
    
    <ul class="layui-nav fly-nav-user">
      
      <!-- 未登入的状态 -->
      <?php if((session('id','','index') < 1)): ?>
      <li class="layui-nav-item">
        <a class="iconfont icon-touxiang layui-hide-xs" href="../user/login.html"></a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('index/User/login'); ?>">登入</a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('Index/User/reg'); ?>">注册</a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过QQ登入', {icon:16, shade: 0.1, time:0})" title="QQ登入" class="iconfont icon-qq"></a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过微博登入', {icon:16, shade: 0.1, time:0})" title="微博登入" class="iconfont icon-weibo"></a>
      </li>
      <?php else: ?>
      <!-- 登入后的状态 -->

      <li class="layui-nav-item">
        <a class="fly-nav-avatar" href="javascript:;">
          <cite class="layui-hide-xs"><?php echo session('username','','index')?></cite>
          <!--<i class="iconfont icon-renzheng layui-hide-xs" title="认证信息：layui 作者"></i>-->
          <i class="layui-badge fly-badge-vip layui-hide-xs">会员</i>
          <img src="<?php echo session('tx','','index')?>">
        </a>
        <dl class="layui-nav-child">
          <dd><a href="<?php echo url('index/User/set'); ?>"><i class="layui-icon">&#xe620;</i>基本设置</a></dd>
          <dd><a href="user/message.html"><i class="iconfont icon-tongzhi" style="top: 4px;"></i>我的消息</a></dd>
          <dd><a href="user/home.html"><i class="layui-icon" style="margin-left: 2px; font-size: 22px;">&#xe68e;</i>我的主页</a></dd>
          <hr style="margin: 5px 0;">
          <dd><a href="<?php echo url('index/User/logout'); ?>" style="text-align: center;">退出</a></dd>
        </dl>
      </li>

      <?php endif; ?>
    </ul>
  </div>
</div>
<div class="layui-container fly-marginTop fly-user-main">
  <ul class="layui-nav layui-nav-tree layui-inline" lay-filter="user">
    <li class="layui-nav-item">
      <a href="home.html">
        <i class="layui-icon">&#xe609;</i>
        我的主页
      </a>
    </li>
    <li class="layui-nav-item">
      <a href="index.html">
        <i class="layui-icon">&#xe612;</i>
        用户中心
      </a>
    </li>
    <li class="layui-nav-item ">
      <a href="set.html">
        <i class="layui-icon">&#xe620;</i>
        基本设置
      </a>
    </li>
    <li class="layui-nav-item">
      <a href="message.html">
        <i class="layui-icon">&#xe611;</i>
        我的消息
      </a>
    </li>
    <?php if($info['static'] == 2): ?>
    <li class="layui-nav-item layui-this">
      <a href="<?php echo url('index/User/tlist'); ?>">
        <i class="layui-icon">&#xe62c;</i>
        分类管理
      </a>
    </li>
    <?php endif; ?>
  </ul>
        <div class="fly-panel fly-panel-user" pad20>

          <form method="post" action="<?php echo url('index/User/addlist'); ?>" class="layui-form layui-form-pane layui-tab-item layui-show">
            <div class="layui-form-item layui-input-block">
              <label for="L_username" class="layui-form-label">分类名称</label>
              <div class="layui-input-inline">
                <input type="text" id="L_username" name="name" required lay-verify="required" autocomplete="off" value="" class="layui-input">
              </div>
              <button class="layui-btn" key="set-mine" lay-filter="*" lay-submit>添加</button>
            </div>
          </form>

          <div class="layui-tab layui-tab-brief" lay-filter="user">
            <table class="layui-table">
              <colgroup>
                <col width="150">
                <col width="70">
                <col width="200">
              </colgroup>
              <thead>
              <tr>
                <th>分类名称</th>
                <th>排序</th>
                <th>创建时间</th>
                <th>操作</th>
              </tr>
              </thead>
              <tbody>
              <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
              <tr>
                <td><?php echo $vo['name']; ?></td>
                <td><input type="text" class="lista" value="<?php echo $vo['paixu']; ?>" order-ad="<?php echo $vo['id']; ?>" style="width: 50px; text-align: center"></td>
                <td><?php echo date("Y-m-d H:i:s",$vo['create_time']); ?></td>
                <td>
                  <a href="" class="layui-btn layui-btn-primary layui-btn-sm" title="编辑"> <i class="layui-icon">&#xe642;</i></a>
                  <a  attr-id="<?php echo $vo['id']; ?>" class="layui-btn layui-btn-primary layui-btn-sm" title="删出"><i class="layui-icon">&#xe640;</i></a>
                </td>
              </tr>
              <?php endforeach; endif; else: echo "" ;endif; ?>
              </tbody>
            </table>
            <div style="text-align: center">
              <?php echo $list->render(); ?>
            </div>
          </div>
        </div>
    </div>
  </div>
</div>
<div class="fly-footer">
  <p><a href="http://fly.layui.com/" target="_blank">Fly社区</a> 2017 &copy; <a href="http://www.layui.com/" target="_blank">layui.com 出品</a></p>
  <p>
    <a href="http://fly.layui.com/jie/3147/" target="_blank">付费计划</a>
    <a href="http://www.layui.com/template/fly/" target="_blank">获取Fly社区模版</a>
    <a href="http://fly.layui.com/jie/2461/" target="_blank">微信公众号</a>
  </p>
</div>

<script src="__STATIC__/layui/layui.js"></script>
<script>
layui.cache.page = '';
layui.cache.user = {
  username: '游客'
  ,uid: -1
  ,avatar: '__STATIC__/images/avatar/00.jpg'
  ,experience: 83
  ,sex: '男'
};
layui.config({
  version: "3.0.0"
  ,base: '__STATIC__/mods/'  //这里实际使用时，建议改成绝对路径
}).extend({
  fly: 'index'
}).use(['fly', 'face'], function(){
  var $ = layui.$
          ,fly = layui.fly;

  $('.jieda-body').each(function(){
    var othis = $(this), html = othis.html();
    othis.html(fly.content(html));
  });

});
</script>

<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_30088308'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/c.php%3Fid%3D30088308' type='text/javascript'%3E%3C/script%3E"));</script>
<script src="__STATIC__/jquery.js"></script>
<script>

  $('.lista').blur(function(){
    var id = $(this).attr('order-ad');
    var order = $(this).val();
    var data = {id:id,paixu:order}
    var url = "<?php echo url('index/User/listorder'); ?>";
    $.post(url,data,function(res){
      if(res.code == 1){
        location.href=res.data;
      }else{
        alert(res.msg);
      }
    },'json');
  });



  $('.layui-btn').click(function(){
    var id = $(this).attr('attr-id');
    $.ajax({
      type: "POST",
      url:"<?php echo url('index/User/deleteall'); ?>",
      data:{id:id},
      success: function(data) {
        if(data.code == 1){
          location.href = data.data;
        }else{
          layer.open({
            title: ''
            ,content:data.msg,
          })
        }
        return false;
      }
    });
  })
</script>
</body>
</html>