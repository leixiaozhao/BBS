<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:64:"E:\www\WWW\wd\public/../application/index\view\index\detail.html";i:1515134344;s:65:"E:\www\WWW\wd\public/../application/index\view\public\header.html";i:1515136397;s:65:"E:\www\WWW\wd\public/../application/index\view\public\footer.html";i:1514967682;}*/ ?>
 
 
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Fly Template v3.0，基于 layui 的极简社区页面模版</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="keywords" content="fly,layui,前端社区">
  <meta name="description" content="Fly社区是模块化前端UI框架Layui的官网社区，致力于为web开发提供强劲动力">
  <link rel="stylesheet" href="__STATIC__/layui/css/layui.css">
  <link rel="stylesheet" href="__STATIC__/css/global.css">
</head>
<body>
<div class="fly-header layui-bg-black">
  <div class="layui-container">
    <a class="fly-logo" href="/">
      <img src="__STATIC__/images/logo.png" alt="layui">
    </a>
    <ul class="layui-nav fly-nav layui-hide-xs">
      <li class="layui-nav-item layui-this">
        <a href="/"><i class="iconfont icon-jiaoliu"></i>交流</a>
      </li>
      <li class="layui-nav-item">
        <a href="case/case.html"><i class="iconfont icon-iconmingxinganli"></i>案例</a>
      </li>
      <li class="layui-nav-item">
        <a href="http://www.layui.com/" target="_blank"><i class="iconfont icon-ui"></i>框架</a>
      </li>
    </ul>
    
    <ul class="layui-nav fly-nav-user">
      
      <!-- 未登入的状态 -->
      <?php if((session('id','','index') < 1)): ?>
      <li class="layui-nav-item">
        <a class="iconfont icon-touxiang layui-hide-xs" href="../user/login.html"></a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('index/User/login'); ?>">登入</a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('Index/User/reg'); ?>">注册</a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过QQ登入', {icon:16, shade: 0.1, time:0})" title="QQ登入" class="iconfont icon-qq"></a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过微博登入', {icon:16, shade: 0.1, time:0})" title="微博登入" class="iconfont icon-weibo"></a>
      </li>
      <?php else: ?>
      <!-- 登入后的状态 -->

      <li class="layui-nav-item">
        <a class="fly-nav-avatar" href="javascript:;">
          <cite class="layui-hide-xs"><?php echo session('username','','index')?></cite>
          <!--<i class="iconfont icon-renzheng layui-hide-xs" title="认证信息：layui 作者"></i>-->
          <i class="layui-badge fly-badge-vip layui-hide-xs">会员</i>
          <img src="<?php echo session('tx','','index')?>">
        </a>
        <dl class="layui-nav-child">
          <dd><a href="<?php echo url('index/User/set'); ?>"><i class="layui-icon">&#xe620;</i>基本设置</a></dd>
          <dd><a href="user/message.html"><i class="iconfont icon-tongzhi" style="top: 4px;"></i>我的消息</a></dd>
          <dd><a href="<?php echo url('index/User/home'); ?>"><i class="layui-icon" style="margin-left: 2px; font-size: 22px;">&#xe68e;</i>我的主页</a></dd>
          <hr style="margin: 5px 0;">
          <dd><a href="<?php echo url('index/User/logout'); ?>" style="text-align: center;">退出</a></dd>
        </dl>
      </li>

      <?php endif; ?>
    </ul>
  </div>
</div>
<div class="layui-hide-xs">
  <div class="fly-panel fly-column">
    <div class="layui-container">
      <ul class="layui-clear">
        <li class="layui-hide-xs layui-this"><a href="/">首页</a></li>
        <li><a href="<?php echo url('index/index/addnews'); ?>">发帖</a></li>
        <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <li><a href="<?php echo url('Index/index/index',array('list_id'=>$vo['id'])); ?>">
          <?php echo $vo['name']; if(($vo['name'] == '分享')): ?>
          <span class="layui-badge-dot"></span>
          <?php endif; ?>
        </a>
        </li>
        <?php endforeach; endif; else: echo "" ;endif; ?>
      </ul>

      <div class="fly-column-right layui-hide-xs">
        <span class="fly-search"><i class="layui-icon"></i></span>
        <a href="<?php echo url('index/index/addnews'); ?>" class="layui-btn">发表新帖</a>
      </div>
      <div class="layui-hide-sm layui-show-xs-block" style="margin-top: -10px; padding-bottom: 10px; text-align: center;">
        <a href="<?php echo url('index/index/addnews'); ?>" class="layui-btn">发表新帖</a>
      </div>
    </div>
  </div>
</div>

<div class="layui-container">
  <div class="layui-row layui-col-space15">
    <div class="layui-col-md8 content detail">
      <div class="fly-panel detail-box">
        <h1><?php echo $news['title']; ?></h1>
        <div class="fly-detail-info">
          <!-- <span class="layui-badge">审核中</span> -->
          <span class="layui-badge layui-bg-green fly-detail-column">动态</span>
          <?php if(($news['end'] == 0)): ?>
          <span class="layui-badge" style="background-color: #999;">未结</span>
          <?php endif; if(($news['end'] == 1)): ?>
          <span class="layui-badge" style="background-color: #5FB878;">已结</span>
          <?php endif; if(($news['top'] == 1)): ?>
          <span class="layui-badge layui-bg-black">置顶</span>
          <?php endif; if(($news['jing'] == 1)): ?>
          <span class="layui-badge layui-bg-red">精帖</span>
          <?php endif; ?>

          <div class="fly-admin-box" data-id="123">
            <?php if((session('static','','index') == 2)): ?>
              <span class="layui-btn layui-btn-xs jie-admin" attr-id="<?php echo $news['id']; ?>" rank="-1" type="del">删除</span>
              <?php if(($news['top'] == 0)): ?>
              <span class="layui-btn layui-btn-xs jie-admin" type="top"  attr-id="<?php echo $news['id']; ?>" field="stick" rank="1">置顶</span>
              <?php else: ?>
              <span class="layui-btn layui-btn-xs jie-admin" type="top"  attr-id="<?php echo $news['id']; ?>" field="stick" rank="0" style="background-color:#ccc;">取消置顶</span>
              <?php endif; if(($news['jing'] == 0)): ?>
              <span class="layui-btn layui-btn-xs jie-admin" type="jing"  attr-id="<?php echo $news['id']; ?>" field="status" rank="1">加精</span>
              <?php else: ?>
              <span class="layui-btn layui-btn-xs jie-admin" type="jing"  attr-id="<?php echo $news['id']; ?>" field="status" rank="0" style="background-color:#ccc;">取消加精</span>
              <?php endif; endif; ?>
          </div>
          <span class="fly-list-nums"> 
            <a href="#comment"><i class="iconfont" title="回答">&#xe60c;</i><?php echo $news['num']; ?></a>
            <i class="iconfont" title="人气">&#xe60b;</i><?php echo $news['host']; ?>
          </span>
        </div>
        <div class="detail-about">
          <a class="fly-avatar" href="../user/home.html">
            <img src="<?php echo $news['tx']; ?>" alt="<?php echo $news['username']; ?>">
          </a>
          <div class="fly-detail-user">
            <a href="../user/home.html" class="fly-link">
              <cite><?php echo $news['username']; ?></cite>
              <i class="iconfont icon-renzheng" title="认证信息：{{ rows.user.approve }}"></i>
              <i class="layui-badge fly-badge-vip">会员</i>
            </a>
            <span><?php echo date("y-m-d H:i",$news['create_time']); ?></span>
          </div>
          <div class="detail-hits" id="LAY_jieAdmin" data-id="123">
            <span style="padding-right: 10px; color: #FF7200">悬赏：<?php echo $news['jifen']; ?>钻石</span>
            <!--<span class="layui-btn layui-btn-xs jie-admin" type="edit"><a href="add.html">编辑此贴</a></span>-->
          </div>
        </div>
        <div class="jieda-body detail-body photos">
          <?php echo $news['content']; ?>
        </div>
      </div>

      <div class="fly-panel detail-box" id="flyReply">
        <fieldset class="layui-elem-field layui-field-title" style="text-align: center;">
          <legend>回帖</legend>
        </fieldset>

        <ul class="jieda" id="jieda">
          <?php if(is_array($hd) || $hd instanceof \think\Collection || $hd instanceof \think\Paginator): $i = 0; $__LIST__ = $hd;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
          <li data-id="111" class="jieda-daan">
            <a name="item-1111111111"></a>
            <div class="detail-about detail-about-reply">
              <a class="fly-avatar" href="">
                <img src="<?php echo $vo['tx']; ?>" alt="<?php echo $vo['username']; ?>">
              </a>
              <div class="fly-detail-user">
                <a href="" class="fly-link">
                  <cite><?php echo $vo['username']; ?></cite>
                  <i class="iconfont icon-renzheng" title="认证信息：XXX"></i>
                  <i class="layui-badge fly-badge-vip">会员</i>
                </a>
                <?php if(($vo['user_id'] == $news['user_id'])): ?>
                <span>(楼主)</span>
                <?php endif; if(($vo['static'] == 2)): ?>
                <span style="color:#5FB878">(管理员)</span>
                <?php endif; ?>
                <!--<span style="color:#FF9E3F">（社区之光）</span>-->
                <?php if(($vo['static'] == -1)): ?>
                <span style="color:#999">（该号已被封）</span>
                <?php endif; ?>

              </div>

              <div class="detail-hits">
                <span><?php echo date("y-m-d H:i:s",$vo['create_time']); ?></span>
              </div>
              <?php if(($vo['caina'] == 1)): ?>
              <i class="iconfont icon-caina" title="最佳答案"></i>
              <?php endif; ?>
            </div>
            <div class="detail-body jieda-body photos">
              <?php if(($vo['static'] != -1)): ?>
              <?php echo $vo['content']; endif; ?>
            </div>
            <div class="jieda-reply">
              <span class="jieda-zan zanok jie-admin" attr-id="<?php echo $vo['id']; ?>" rank="<?php echo $vo['user_id']; ?>"  type="zan">
                <i class="iconfont icon-zan"></i>
                <em><?php echo $vo['zan']; ?></em>
              </span>
              <span type="reply">
                <i class="iconfont icon-svgmoban53"></i>
                回复
              </span>
              <div class="jieda-admin">
                <?php if((session('static','','index') == 2)): ?>
                <!--<span type="edit">编辑</span>-->
                <!--<span type="del">删除</span>-->
                <?php endif; if((session('id','','index') == $news['user_id'])): if(($vo['caina'] == 0)): ?>
                <span class="jieda-accept jie-admin" attr-id="<?php echo $vo['id']; ?>" rank="<?php echo $vo['user_id']; ?>"  type="accept">采纳</span>
                <?php endif; endif; ?>
              </div>
            </div>
          </li>
          <?php endforeach; endif; else: echo "" ;endif; if((empty($hd))): ?>
           <li class="fly-none">消灭零回复</li>
          <?php endif; ?>
        </ul>
        
        <div class="layui-form layui-form-pane">
          <form action="<?php echo url('index/Index/reply'); ?>" method="post">
            <div class="layui-form-item layui-form-text">
              <a name="comment"></a>
              <div class="layui-input-block">
                <textarea id="L_content" name="content" required lay-verify="required" placeholder="请输入内容"  class="layui-textarea fly-editor" style="height: 150px;"></textarea>
              </div>
            </div>
            <div class="layui-form-item">
              <input type="hidden" name="wid" value="<?php echo $news['id']; ?>">
              <button class="layui-btn" lay-filter="*" lay-submit>提交回复</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <div class="layui-col-md4">
      <dl class="fly-panel fly-list-one">
        <dt class="fly-panel-title">本周热议</dt>
        <?php if(is_array($re) || $re instanceof \think\Collection || $re instanceof \think\Paginator): $i = 0; $__LIST__ = $re;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
        <dd>
          <a href="<?php echo url('index/index/detail',array('id'=>$vo['id'])); ?>"><?php echo $vo['title']; ?></a>
          <span><i class="iconfont icon-pinglun1"></i><?php echo $vo['num']; ?></span>
        </dd>
        <?php endforeach; endif; else: echo "" ;endif; ?>
        <!-- 无数据时 -->
        <!--
        <div class="fly-none">没有相关数据</div>
        -->
      </dl>
      <div class="fly-panel">
        <div class="fly-panel-title">
          这里可作为广告区域
        </div>
        <div class="fly-panel-main">
          <a href="" target="_blank" class="fly-zanzhu" time-limit="2018.01.2" style="background-color: #5FB878;">QQ78245080</a>
        </div>
      </div>
      <!--<div class="fly-panel" style="padding: 20px 0; text-align: center;">-->
        <!--<img src="../../res/images/weixin.jpg" style="max-width: 100%;" alt="layui">-->
        <!--<p style="position: relative; color: #666;">微信扫码关注 layui 公众号</p>-->
      <!--</div>-->
    </div>
  </div>
</div>
<script src="__STATIC__/jquery.js"></script>
<script>

//    layer.confirm('123', {
//      btn: ['确定'] //按钮
//    }, function(){
//      location.href = res.data;
//  jieda-zan
//    })
    $(".jie-admin").click(function(){
      var id = $(this).attr('attr-id');
      var jing = $(this).attr('rank');
      var type = $(this).attr('type');
      $.ajax({
        type: "POST",
        url:"<?php echo url('index/Set/jing'); ?>",
        data:{id:id,jing:jing,type:type},
        success: function(data) {
          if(data.code == 1){
            window.location.href=data.data
          }else{
            layer.open({
              title: '请先登陆'
              ,content:data.msg,

            });
          }
          return false;
        }
      });
    })

</script>
<div class="fly-footer">
  <p><a href="http://fly.layui.com/" target="_blank">Fly社区</a> 2017 &copy; <a href="http://www.layui.com/" target="_blank">layui.com 出品</a></p>
  <p>
    <a href="http://fly.layui.com/jie/3147/" target="_blank">付费计划</a>
    <a href="http://www.layui.com/template/fly/" target="_blank">获取Fly社区模版</a>
    <a href="http://fly.layui.com/jie/2461/" target="_blank">微信公众号</a>
  </p>
</div>

<script src="__STATIC__/layui/layui.js"></script>
<script>
layui.cache.page = '';
layui.cache.user = {
  username: '游客'
  ,uid: -1
  ,avatar: '__STATIC__/images/avatar/00.jpg'
  ,experience: 83
  ,sex: '男'
};
layui.config({
  version: "3.0.0"
  ,base: '__STATIC__/mods/'  //这里实际使用时，建议改成绝对路径
}).extend({
  fly: 'index'
}).use(['fly', 'face'], function(){
  var $ = layui.$
          ,fly = layui.fly;

  $('.jieda-body').each(function(){
    var othis = $(this), html = othis.html();
    othis.html(fly.content(html));
  });

});
</script>

<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_30088308'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/c.php%3Fid%3D30088308' type='text/javascript'%3E%3C/script%3E"));</script>
</body>
</html>