<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:72:"/www/wwwroot/www.iq36.com/public/../application/index/view/user/set.html";i:1515138158;s:77:"/www/wwwroot/www.iq36.com/public/../application/index/view/public/header.html";i:1515209566;s:77:"/www/wwwroot/www.iq36.com/public/../application/index/view/public/footer.html";i:1515137238;}*/ ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>帐号设置</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <meta name="keywords" content="PHP,Thinkphp,框架">
  <meta name="description" content="PHP论坛哈尔滨论坛，讨论PHP框架论坛">
  <link rel="stylesheet" href="__STATIC__/layui/css/layui.css">
  <link rel="stylesheet" href="__STATIC__/css/global.css">
</head>
<body>
<div class="fly-header layui-bg-black">
  <div class="layui-container">
    <a class="fly-logo" href="/">
      <img src="__STATIC__/images/logo.png" height="50" alt="layui">
    </a>
    <ul class="layui-nav fly-nav layui-hide-xs">
      <li class="layui-nav-item layui-this">
        <a href="/"><i class="iconfont icon-jiaoliu"></i>交流</a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('index/index/addnews'); ?>"><i class="iconfont icon-fabu"></i>发表</a>
      </li>
      <li class="layui-nav-item">
        <a href="/" target="_blank"><i class="iconfont icon-shijian"></i><?php echo date('Y-m-d H:i:s')?></a>
      </li>
    </ul>
    
    <ul class="layui-nav fly-nav-user">
      
      <!-- 未登入的状态 -->
      <?php if((session('id','','index') < 1)): ?>
      <li class="layui-nav-item">
        <a class="iconfont icon-touxiang layui-hide-xs" href="../user/login.html"></a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('index/User/login'); ?>">登入</a>
      </li>
      <li class="layui-nav-item">
        <a href="<?php echo url('Index/User/reg'); ?>">注册</a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过QQ登入', {icon:16, shade: 0.1, time:0})" title="QQ登入" class="iconfont icon-qq"></a>
      </li>
      <li class="layui-nav-item layui-hide-xs">
        <a href="" onclick="layer.msg('正在通过微博登入', {icon:16, shade: 0.1, time:0})" title="微博登入" class="iconfont icon-weibo"></a>
      </li>
      <?php else: ?>
      <!-- 登入后的状态 -->

      <li class="layui-nav-item">
        <a class="fly-nav-avatar" href="javascript:;">
          <cite class="layui-hide-xs"><?php echo session('username','','index')?></cite>
          <!--<i class="iconfont icon-renzheng layui-hide-xs" title="认证信息：layui 作者"></i>-->
          <i class="layui-badge fly-badge-vip layui-hide-xs">会员</i>
          <img src="/<?php echo session('tx','','index')?>">
        </a>
        <dl class="layui-nav-child">
          <dd><a href="<?php echo url('index/User/set'); ?>"><i class="layui-icon">&#xe620;</i>基本设置</a></dd>
          <dd><a href="<?php echo url('index/User/index'); ?>"><i class="iconfont icon-tongzhi" style="top: 4px;"></i>我的发帖</a></dd>
          <dd><a href="<?php echo url('index/User/home'); ?>"><i class="layui-icon" style="margin-left: 2px; font-size: 22px;">&#xe68e;</i>我的主页</a></dd>
          <hr style="margin: 5px 0;">
          <dd><a href="<?php echo url('index/User/logout'); ?>" style="text-align: center;">退出</a></dd>
        </dl>
      </li>

      <?php endif; ?>
    </ul>
  </div>
</div>

<div class="layui-container fly-marginTop fly-user-main">
  <ul class="layui-nav layui-nav-tree layui-inline" lay-filter="user">
    <li class="layui-nav-item">
      <a href="<?php echo url('index/User/home'); ?>">
        <i class="layui-icon">&#xe609;</i>
        我的主页
      </a>
    </li>
    <!--<li class="layui-nav-item">-->
      <!--<a href="index.html">-->
        <!--<i class="layui-icon">&#xe612;</i>-->
        <!--用户中心-->
      <!--</a>-->
    <!--</li>-->
    <li class="layui-nav-item layui-this">
      <a href="<?php echo url('index/User/set'); ?>">
        <i class="layui-icon">&#xe620;</i>
        基本设置
      </a>
    </li>
    <li class="layui-nav-item">
      <a href="<?php echo url('index/User/index'); ?>">
        <i class="layui-icon">&#xe611;</i>
        我的发帖
      </a>
    </li>
    <?php if($info['static'] == 2): ?>
    <li class="layui-nav-item">
      <a href="<?php echo url('index/User/tlist'); ?>">
        <i class="layui-icon">&#xe62c;</i>
        分类管理
      </a>
    </li>
    <?php endif; ?>
  </ul>

  <div class="site-tree-mobile layui-hide">
    <i class="layui-icon">&#xe602;</i>
  </div>
  <div class="site-mobile-shade"></div>
  
  <div class="site-tree-mobile layui-hide">
    <i class="layui-icon">&#xe602;</i>
  </div>
  <div class="site-mobile-shade"></div>


  <div class="fly-panel fly-panel-user" pad20>
    <div class="layui-tab layui-tab-brief" lay-filter="user">
      <ul class="layui-tab-title" id="LAY_mine">
        <li class="layui-this" lay-id="info">我的资料</li>
        <li lay-id="avatar">头像</li>
        <li lay-id="pass">密码</li>
        <!--<li lay-id="bind">帐号绑定</li>-->
      </ul>
      <div class="layui-tab-content" style="padding: 20px 0;">
        <form class="layui-form layui-form-pane layui-tab-item layui-show">
          <form method="post" action="<?php echo url('index/User/set'); ?>">
            <div class="layui-form-item">
              <label for="L_email" class="layui-form-label">账号</label>
              <div class="layui-input-inline">
                <input type="text" id="L_email" name="name" readonly="readonly" required lay-verify="required" autocomplete="off" value="<?php echo $info['name']; ?>" class="layui-input">
              </div>

            </div>
            <div class="layui-form-item">
              <label for="L_username" class="layui-form-label">昵称</label>
              <div class="layui-input-inline">
                <input type="text" id="L_username" name="username" required lay-verify="required" autocomplete="off" value="<?php echo $info['username']; ?>" class="layui-input">
              </div>
            </div>
            <div class="layui-form-item layui-form-text">
              <label for="L_sign" class="layui-form-label">签名</label>
              <div class="layui-input-block">
                <textarea placeholder="随便写些什么刷下存在感" id="L_sign"  name="content" autocomplete="off" class="layui-textarea" style="height: 80px;"><?php echo $info['content']; ?></textarea>
              </div>
            </div>
            <div class="layui-form-item">
              <input type="hidden" name="id" value="<?php echo session('id','','index')?>">
              <button class="layui-btn" key="set-mine" lay-filter="*" lay-submit>确认修改</button>
            </div>
          </form>


          <div class="layui-form layui-form-pane layui-tab-item">
            <form method="post"  action="<?php echo url('index/User/set'); ?>">
              <div class="layui-form-item">
                <div class="avatar-add">
                  <p id="demoText2">建议尺寸168*168，支持jpg、png、gif，最大不能超过50KB</p>
                  <button type="button" class="layui-btn upload-img" id="test1">
                    <i class="layui-icon">&#xe67c;</i>上传头像
                  </button>
                  <img id="demo1" src="<?php echo $info['tx']; ?>">
                  <span class="loading"></span>
                </div>
                <div class="layui-form-item" id="demo2">
                  <input type="hidden" name="id" value="<?php echo $info['id']; ?>">
                  <button class="layui-btn" key="set-mine" lay-filter="*" lay-submit>确认修改</button>
                </div>
              </div>
            </form>
          </div>

          
          <div class="layui-form layui-form-pane layui-tab-item">
            <form action="<?php echo url('index/User/set'); ?>" method="post">
              <div class="layui-form-item">
                <label for="L_nowpass" class="layui-form-label">当前密码</label>
                <div class="layui-input-inline">
                  <input type="password" id="L_nowpass" name="nowpass" required lay-verify="required" autocomplete="off" class="layui-input">
                </div>
              </div>
              <div class="layui-form-item">
                <label for="L_pass" class="layui-form-label">新密码</label>
                <div class="layui-input-inline">
                  <input type="password" id="L_pass" name="pass" required lay-verify="required" autocomplete="off" class="layui-input">
                </div>
                <div class="layui-form-mid layui-word-aux">6到16个字符</div>
              </div>
              <div class="layui-form-item">
                <label for="L_repass" class="layui-form-label">确认密码</label>
                <div class="layui-input-inline">
                  <input type="password" id="L_repass" name="repass" required lay-verify="required" autocomplete="off" class="layui-input">
                </div>
              </div>
              <div class="layui-form-item">
                <input type="hidden" name="id" value="<?php echo $info['id']; ?>">
                <button class="layui-btn" key="set-mine" lay-filter="*" lay-submit>确认修改</button>
              </div>
            </form>
          </div>
          
          <div class="layui-form layui-form-pane layui-tab-item">
            <ul class="app-bind">
              <li class="fly-msg app-havebind">
                <i class="iconfont icon-qq"></i>
                <span>已成功绑定，您可以使用QQ帐号直接登录Fly社区，当然，您也可以</span>
                <a href="javascript:;" class="acc-unbind" type="qq_id">解除绑定</a>
                
                <!-- <a href="" onclick="layer.msg('正在绑定微博QQ', {icon:16, shade: 0.1, time:0})" class="acc-bind" type="qq_id">立即绑定</a>
                <span>，即可使用QQ帐号登录Fly社区</span> -->
              </li>
              <li class="fly-msg">
                <i class="iconfont icon-weibo"></i>
                <!-- <span>已成功绑定，您可以使用微博直接登录Fly社区，当然，您也可以</span>
                <a href="javascript:;" class="acc-unbind" type="weibo_id">解除绑定</a> -->
                
                <a href="" class="acc-weibo" type="weibo_id"  onclick="layer.msg('正在绑定微博', {icon:16, shade: 0.1, time:0})" >立即绑定</a>
                <span>，即可使用微博帐号登录Fly社区</span>
              </li>
            </ul>
          </div>
        </div>

      </div>
    </div>
  </div>
</div>
<div class="fly-footer">
  <!--<p><a href="http://fly.layui.com/" target="_blank">Fly社区</a> 2017 &copy; <a href="http://www.layui.com/" target="_blank">layui.com 出品</a></p>-->
  <!--<p>-->
    <!--<a href="http://fly.layui.com/jie/3147/" target="_blank">付费计划</a>-->
    <!--<a href="http://www.layui.com/template/fly/" target="_blank">获取Fly社区模版</a>-->
    <!--<a href="http://fly.layui.com/jie/2461/" target="_blank">微信公众号</a>-->
  <!--</p>-->
</div>

<script src="__STATIC__/layui/layui.js"></script>
<script>
layui.cache.page = '';
layui.cache.user = {
  username: '游客'
  ,uid: -1
  ,avatar: '__STATIC__/images/avatar/00.jpg'
  ,experience: 83
  ,sex: '男'
};
layui.config({
  version: "3.0.0"
  ,base: '__STATIC__/mods/'  //这里实际使用时，建议改成绝对路径
}).extend({
  fly: 'index'
}).use(['fly', 'face'], function(){
  var $ = layui.$
          ,fly = layui.fly;

  $('.jieda-body').each(function(){
    var othis = $(this), html = othis.html();
    othis.html(fly.content(html));
  });

});
</script>

<script type="text/javascript">var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");document.write(unescape("%3Cspan id='cnzz_stat_icon_30088308'%3E%3C/span%3E%3Cscript src='" + cnzz_protocol + "w.cnzz.com/c.php%3Fid%3D30088308' type='text/javascript'%3E%3C/script%3E"));</script>
<script src="__STATIC__/jquery.js"></script>
<script>
  layui.use('upload', function(){
    var upload = layui.upload;
    //执行实例
    var uploadInst = upload.render({
      elem: '#test1' //绑定元素
      ,url: "<?php echo url('index/User/upload'); ?>" //上传接口
      ,size: 50
      ,done: function(res){
        $('#demo1').attr('src', res.data);
        $('#demo2').append('<input type="hidden" name="tx" value='+res.data+'>');
      }
      ,error: function(){
        layer.alert('见到你真的很高兴，但是你头像上传失败了', {icon: 6});
      }
    });
  });
</script>
</body>
</html>