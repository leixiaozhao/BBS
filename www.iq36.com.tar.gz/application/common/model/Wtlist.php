<?php
namespace app\common\model;
use think\Model;
class Wtlist extends Model{

    public function cateadd($data){
        $data['status'] = 1;
        $data['create_time'] = time();
        return $this->save($data);
    }

    public function getonelist(){
        $data = [
            'status'=>1,

        ];
        $order = [
            'list_order'=>'desc'
        ];
        return $this
            ->where($data)
            ->order($order)
            -> paginate(2);
    }

    public function getListtow($parent_id){
        $data = [
            'status'=>['neq','-1'],
            'parent_id'=>$parent_id
        ];
        $order = [
            'listorder'=>'desc'
        ];
        return $this
            ->where($data)
            ->order($order)
            ->select();
    }

    public function getlist($num){

        $order = [
            'list_order'=>'desc'
        ];
        $where = [
            'status'=>1
        ];

        return $this
            ->where($where)
            ->order($order)
            ->limit($num)
            ->select();
    }

    public function uplist($id){
        return $this->save(['status'=>-1],['id'=>$id]);
    }

    public function listorder($data){
        return $this->save(['list_order'=>$data['listorder']],['id'=>$data['id']]);
    }
}