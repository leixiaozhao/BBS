<?php
namespace app\index\Controller;
use think\Controller;
use think\Request;
use think\File;

class User extends Controller{
    public function reg(){
        if(Request()->isPost()){
            $data = input('post.');
            if(empty($data['name']) || empty($data['username']) || empty($data['pass'])){
                $this->result('',0,'请填写相关信息');
            }
            if($data['pass'] != $data['repass']){
                $this->result('',0,'两次密码不一致');
            }
            if(!captcha_check($data['vercode'])){
                $this->result('',0,'验证码错误');
            };
            $tx = ['image/0.jpg', 'image/00.jpg', 'image/1.jpg', 'image/2.jpg', 'image/3.jpg', 'image/4.jpg', 'image/5.jpg', 'image/6.jpg', 'image/7.jpg', 'image/8.jpg', 'image/9.jpg', 'image/10.jpg', 'image/11.jpg', 'image/default.png',];
            $num =  array_rand($tx);

            $arr =[
                'name'=>$data['name'],
                'username'=>$data['username'],
                'pass'=>$data['pass'],
                'create_time'=>time(),
                'tx'=>$tx[$num],
                'qid'=>time(),
                'jifen'=>0,
                'static'=>1,
                'up_time'=>time(),
            ];
            $info = Db('User')->where(['name'=>$data['name']])->find();
            if($info){
                $this->result('',0,'账号存在了！');
            }
            $info = Db('User')->where(['username'=>$data['username']])->find();
            if($info){
                $this->result('',0,'昵称存在了！');
            }
            $res =db('user')->insertGetId($arr);
            if($res){
                session('username',$arr['username'],'index');
                session('tx',$arr['tx'],'index');
                session('id',$res,'index');
                session('name',$arr['name'],'index');
                $this->result('http://www.iq36.com',1,'注册成功');
            }else{
                $this->result('',0,'注册失败');
            }
        }else{

            return $this->fetch();
        }

    }

    public function login(){
        if(Request()->isPost()){
            session(null, 'index');
            $info = input('post.');
            $res = Db('User')->where(['name'=>$info['name']])->find();
            if($res){
                if($res['pass'] !=$info['pass']){
                    $this->result('',0,'密码不正确');
                }
                if(!captcha_check($info['vercode'])){
                    $this->result('',0,'验证码错误');
                };
                session(null, 'index');
                session(null, 'think');
                session(null);
                session('username',$res['username'],'index');
                session('tx',$res['tx'],'index');
                session('id',$res['id'],'index');
                session('name',$res['name'],'index');
                session('static',$res['static'],'index');
                $this->result('http://www.iq36.com',1,'登入成功');
            }else{
                $this->result('',0,'账号不存在');
            }
        }else{
            return $this->fetch();
        }

    }



    public function set(){
        if(Request()->isPost()){
            $info = input('post.');
            unset($info['file']);
            if(isset($info['pass'])){
                if($info['pass'] != $info['repass']){
                    $this->result('',0,'两次密码不一致');
                }
                unset($info['repass']);
                unset($info['nowpass']);
            }
            $res = Db('User')->where(['id'=>$info['id']])->update($info);
            if($res){

                session(null, 'index');
                session(null, 'think');
                session(null);
                $res = Db('User')->where(['id'=>$info['id']])->find();
                session('username',$res['username'],'index');
                session('tx',$res['tx'],'index');
                session('id',$res['id'],'index');
                session('name',$res['name'],'index');
                $this->result(url('index/User/set'),1,'修改成功');
            }else{
                $this->result(url('index/User/set'),0,'修改失败');
            }
        }else{
            $info = Db('User')->where(['id'=>session('id','','index')])->find();
            return $this->fetch('',['info'=>$info]);
        }
    }

    public function upload(){
        $file =  Request::instance()->file('file');
        $info = $file->move( 'uploads');
        if($info){
            $this->result('\\'.$info->getPathname(),1,'上传成功');
        }else{
            $this->result($file->getError());
        }
    }


    public function logout(){
        session(null, 'index');
        session(null, 'think');
        session(null);
        $this->redirect('http://www.iq36.com');
    }


    public function tlist(){
        $info = Db('User')->where(['id'=>session('id','','index')])->find();
        $list = Db('list')->where(['static'=>1])->order('paixu desc')->paginate(8);
        return $this->fetch('',['info'=>$info,'list'=>$list]);
    }

    public function addlist(){
        $arr = input('post.');
        $arr['create_time'] = time();
        $arr['static'] = 1;
        $arr['paixu'] = 0;
        $res =db('list')->insert($arr);
        if($res){
            $this->result(url('Index/User/tlist'),1,'添加成功');
        }else{
            $this->result('',0,'添加失败');
        }
    }

    public function deleteall(){
        $id = input('post.id');

        $res = Db('list')->where(['id'=>$id])->update(['static'=>-1]);
        if($res){
            $this->result(url('index/User/tlist'),1,'删出成功');
        }else{
            $this->result('',1,'删出失败');
        }
    }

    public function listorder(){
        $data = input('post.');
        $res = Db('list')->where(['id'=>$data['id']])->update(['paixu'=>$data['paixu']]);
        if($res){
            $this->result(url('index/User/tlist'),1,'排序成功');
        }else{
            $this->result('',0,'排序失败');
        }
    }

    public function home(){
        $info = Db('User')->where(['id'=>session('id','','index')])->find();
        $news = Db('news')->where(['user_id'=>session('id','','index')])->order('create_time desc')->select();
        $hd = Db('hd')
            ->alias('a')
            ->field('a.*,b.title,b.id as bid')
            ->join('zl_news b','a.wid = b.id','LEFT')
            ->where(['a.user_id'=>session('id','','index')])
            ->order('a.create_time')
            ->limit(8)
            ->select();
        return $this->fetch('',['info'=>$info,'news'=>$news,'hd'=>$hd]);
    }

    public function index(){
        $news = Db('news')->where(['user_id'=>session('id','','index')])->order('create_time desc')->paginate(10);

        return $this->fetch('',['news'=>$news]);
    }


}
