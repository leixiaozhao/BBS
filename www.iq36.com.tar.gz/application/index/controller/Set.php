<?php
namespace app\index\controller;
use think\Controller;
use think\Request;

class Set extends Controller{
    public function jing(){
        $data = input('post.');
        switch ($data['type'])
        {
            case 'jing';
                $res = Db('news')->where(['id'=>$data['id']])->update(['jing'=>$data['jing']]);
                break;
            case 'top';
                $res = Db('news')->where(['id'=>$data['id']])->update(['top'=>$data['jing']]);
                break;
            case 'del';
                $res = Db('news')->where(['id'=>$data['id']])->update(['static'=>$data['jing']]);
                break;
            case 'zan';
                $info = db('zan')->where(['hd_id'=>$data['id'],'s_id'=>session('id','','index')])->find();
                if($info){
                    $this->result('',0,'你已经赞过？');
                    $res = false;
                }else{
                    $res =db('zan')->insert(['hd_id'=>$data['id'],'user_id'=>$data['jing'],'s_id'=>session('id','','index')]);
                }
                break;
            case 'accept';
                $news = db('hd')->where(['id'=>$data['id']])->find();
                $res = db('news')->where(['id'=>$news['wid']])->update(['end'=>1]);
                $news = db('news')->where(['id'=>$news['wid']])->find();
                db('hd')->where(['id'=>$data['id']])->update(['caina'=>1]);
                db('user')->where('id', $data['jing'])-> setInc('jifen',10);
                db('user')->where('id', $data['jing'])-> setInc('jifen',$news['jifen']);
                break;
            default:
                $this->result('',0,'你要干什么？');
        }
        if($res){
            $this->result($_SERVER['HTTP_REFERER'],1,'设置成功');
        }else{
            $this->result('',0,'设置失败');
        }
    }
}
