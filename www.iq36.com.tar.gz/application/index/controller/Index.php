<?php
namespace app\index\controller;
use think\Controller;
use think\Request;
use think\Route;

class Index extends Controller
{
    public function index(){
        $end = Request::instance() -> route("end");
        $list_id = Request::instance() -> route("list_id");
        $roder = Request::instance() -> route("desc");
        $jing = Request::instance() -> route("jing");
        $list = Db('list')->where(['static'=>1])->order('paixu desc')->limit(6)->select();
        $where['a.static'] = 1;
        $where['a.top'] = ['neq',1];
        if(!empty($list_id)){$where['a.list_id'] =$list_id; }
        if(!empty($jing)){$where['a.jing'] =$jing; }
        if(!empty($end)){
            if($end == 'w'){
                $where['a.end'] =0;
            }else{
                $where['a.end'] =1;
            }
        }
        if(!empty($roder)){
            $roder = 'num desc';
        }else{
            $roder= 'a.create_time desc';
        }

        $news = Db('news')
            ->alias('a')
            ->field('a.*,b.username,b.tx,c.name as cname,count(d.id) as num')
            ->join('zl_user b','a.user_id = b.id','LEFT')
            ->join('zl_list c','a.list_id = c.id','LEFT')
            ->join('zl_hd d','a.id = d.wid','LEFT')
            ->group('a.id')
            ->where($where)->order($roder)->paginate(10);

        $top = Db('news')
            ->alias('a')
            ->field('a.*,b.username,b.tx,c.name as cname')
            ->join('zl_user b','a.user_id = b.id','LEFT')
            ->join('zl_list c','a.list_id = c.id','LEFT')
            ->where(['a.static'=>1,'a.top'=>['eq',1]])->order('a.create_time desc')->paginate(10);


        $re =  Db('news')
            ->alias('a')
            ->field('a.*,b.username,b.tx,c.name as cname,count(d.id) as num')
            ->join('zl_user b','a.user_id = b.id','LEFT')
            ->join('zl_list c','a.list_id = c.id','LEFT')
            ->join('zl_hd d ','a.id = d.wid ','LEFT')
            ->group('a.id')
            ->where(['a.static'=>1])->order('num desc')->limit(5)->select();

        $wx = Db('news')
            ->alias('a')
            ->field('a.*,b.username,b.tx,c.name as cname,count(d.id) as num')
            ->join('zl_user b','a.user_id = b.id','LEFT')
            ->join('zl_list c','a.list_id = c.id','LEFT')
            ->join('zl_hd d ','a.id = d.wid ','LEFT')
            ->group('a.id')
            ->where(['a.static'=>1])->order('a.host desc')->limit(5)->select();

        $ht = Db('user')
            ->alias('a')
            ->field('a.*,count(b.id)as num')
            ->join('zl_hd b','a.id = b.user_id','LEFT')
            ->group('a.id')
            ->order('num desc')->limit(12)->select();

        return $this->fetch('',['list'=>$list,'news'=>$news,'top'=>$top,'re'=>$re,'wx'=>$wx,'ht'=>$ht]);
    }


    public function addnews(){

        if(Request()->isPost()){
            $data = input('post.');
            $data['static'] = 1;
            $data['static'] = 1;
            $data['top'] = 0;
            $data['jing'] = 0;
            $data['end'] = 0;
            $data['create_time'] = time();
            $data['host'] = 0;
            $data['zt'] = 0;
            $data['paixu'] = 0;
            $data['user_id'] =  session('id','','index');
            $data['title'] = htmlentities( $data['title']);
            $data['content'] = htmlentities($data['content']);

            $info = Db('user')->where(['id'=>session('id','','index')])->find();
            if(!$info){
                $this->result('',0,'请先登陆');
            }
            if($info['jifen'] < $data['jifen']){
                $this->result('',0,'你的钻石不足');
            }
            if(!captcha_check($data['vercode'])){
                $this->result('',0,'验证码错误');
            };
            unset($data['vercode']);
            $res =db('news')->insert($data);
            if($res){
                db('user')->where('id', session('id','','index'))->setDec('jifen',$data['jifen']);
                db('user')->where('id', session('id','','index'))-> setInc('jifen',5);
                $this->result('http://www.iq36.com',1,'发表成功了快去首页看看吧！');
            }else{
                $this->result('http://www.iq36.com',0,'发表失败请审查你的信息或联系管理员');
            }
        }else{
            $list = Db('list')->where(['static'=>1])->order('paixu desc')->select();
            return $this->fetch('',['list'=>$list]);
        }

    }

    public function detail($id){
        $news = Db('news')
            ->alias('a')
            ->field('a.*,b.username,b.tx,c.name as cname,count(d.id) as num')
            ->join('zl_user b','a.user_id = b.id','LEFT')
            ->join('zl_list c','a.list_id = c.id','LEFT')
            ->join('zl_hd d','a.id = d.wid','LEFT')
            ->group('a.id')
            ->where(['a.id'=>$id])
            ->find();

        $hd =Db('hd')
            ->alias('a')
            ->field('a.*,b.username,b.tx,b.static,count(c.id)as zan')
            ->join('zl_user b','a.user_id = b.id','LEFT')
            ->join('zl_zan c','a.id = c.hd_id','LEFT')
            ->group('a.id')
            ->where(['a.wid'=>$id])
            ->select();

        $re =  Db('news')
            ->alias('a')
            ->field('a.*,b.username,b.tx,c.name as cname,count(d.id) as num')
            ->join('zl_user b','a.user_id = b.id','LEFT')
            ->join('zl_list c','a.list_id = c.id','LEFT')
            ->join('zl_hd d ','a.id = d.wid ','LEFT')
            ->group('a.id')
            ->where(['a.static'=>1])->order('num desc')->limit(5)->select();

        db('news')->where('id', $id)->setInc('host',1);
        $list = Db('list')->where(['static'=>1])->order('paixu desc')->paginate(6);
        return $this->fetch('',['news'=>$news,'hd'=>$hd,'list'=>$list,'re'=>$re]);
    }

    public function reply(){

        $data = input('post.');
        $data['content'] = htmlentities($data['content']);
        $data['create_time'] = time();
        $data['static'] =1;
        $data['caina'] =0;
        $data['user_id'] =session('id','','index');
        $res =db('hd')->insert($data);

        if($res){
            db('user')->where('id', session('id','','index'))->setInc('jifen',2);
            $this->result($_SERVER['HTTP_REFERER'],1,'评论成功');
        }else{
            $this->result($_SERVER['HTTP_REFERER'],0,'评论失败');
        }
    }

    public function qiandao(){

            $info = Db('user')->where(['id'=>session('id','','index')])->find();
               
            if(!$info){
                $this->result('',0,'请先登陆');
            }

	    if($info['qiandao'] == date('d',time()) ){
                $this->result($_SERVER['HTTP_REFERER'],0,'今天你已经签到');
            }

            $jifen = db('user')->where('id', session('id','','index'))->setInc('jifen',10);
            $res = Db('User')->where(['id'=>session('id','','index')])->update(['qiandao'=>date('d',time())]);
            $this->result($_SERVER['HTTP_REFERER'],1,'签到成功');


    }

}
