<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006~2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: liu21st <liu21st@gmail.com>
// +----------------------------------------------------------------------

return [
        'logout/'=>'index/user/logout',

        'news/:list_id'=>'index/index/index',
        'end/:end'=>'index/index/index',
        'jing/:jing'=>'index/index/index',
        'desc/:desc'=>'index/index/index',
        'login'=>'index/User/login',
        'reg'=>'index/User/reg',
        'set'=>'index/User/set',
        'upload'=>'index/User/upload',
        'list'=>'index/User/tlist',
        'addlist'=>'index/User/addlist',
        'delete'=>'index/User/deleteall',
        'order'=>'index/User/listorder',
        'add'=>'index/Index/addnews',
        'uploadimg'=>'index/User/uploadimg',
        'detail/:id'=>'index/Index/detail',
        'reply'=>'index/Index/reply',
        'jing'=>'index/Set/jing',
        'qiandao'=>'index/index/qiandao',
        'home'=>'index/User/home',
        'puth'=>'index/User/index',
];
